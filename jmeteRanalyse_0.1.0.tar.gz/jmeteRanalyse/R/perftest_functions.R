# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

library(tidyverse)
library(scales)
library(odbc)
library(DT)
library(base)
library(png)
library(knitr)
library(ggthemes)
library(readr)
library(flexdashboard)
library(plotly)
library(dplyr)
library(xlsx)
library(ggforce)
library(DBI)


binDataFrameTimes<-function(bindf, binCol, binSize)
{

  minVal<-min(bindf[[binCol]])
  maxVal<-max(bindf[[binCol]])
  binBreaks<-(maxVal-minVal)/binSize
  binSize<-as.integer(binSize)
  newCol<-sprintf("binned%s" , binCol)

  success<-tryCatch(
    {

      bindf[[newCol]]<-cut(bindf[[binCol]] , breaks=binBreaks , labels = FALSE)
      bindf[[newCol]] <- (bindf[[newCol]]*binSize) + minVal
      #Now convert back to a human time
      bindf[[newCol]]<-as.POSIXct( bindf[[newCol]] , origin="1970-01-01"  ,tz=Sys.timezone()                              )
      cat(sprintf("Minimum bin ref: %f. Maximum bin ref:%f. Calculating on a bin size of %f on new column %s with %f bins." , minVal , maxVal, binSize, newCol , binBreaks))
    },
    error=function(e)
    {
      cat(sprintf("ERROR : Function binData: %s with binCol of %s and binSize of %f" , as.character(e) , binCol , binSize ))
      bindf<-0
    }
  )

  return (bindf)
}



jmeterprepDf <- function(file = file,filterPattern=filterPattern,rtcolumn= rtcolumn,binsize= binsize) {

  if (!requireNamespace("tidyverse", quietly = TRUE)) {
    stop("Package \"tidyverse\" needed for this function to work. Please install it.",
         call. = FALSE)
  }

  resultsDf<-read_csv(file, col_names =TRUE , quote="\"")
  print(sprintf("Reading in Results file with %s rows",nrow(resultsDf)))
  resultsDf<-mutate(resultsDf , epoch=startTime)

  if(binsize!="none"){
  resultsDf <- binDataFrameTimes(resultsDf,"epoch",binsize)
  }

  print(sprintf("Coverting epoch StartTime column to POSIXct time",""))
  resultsDf<-mutate(resultsDf , startTime=as.POSIXct(startTime , tz=Sys.timezone() , origin="1970-01-01" ))

  print(sprintf("Coverting %s to seconds",rtcolumn))
  resultsDf <- mutate(resultsDf, responseTime=(resultsDf[[rtcolumn]]/1000))
  print(sprintf("Filtering based on filterPattern ",filterPattern))
  resultsDf <- resultsDf %>% dplyr::filter(. , !grepl(filterPattern ,sampleLabel))

  print(sprintf("Converting isSuccsessful column to Pass and Fail from 0 and 1",filterPattern))
  resultsDf<-mutate(resultsDf , isSuccsessful = if_else(isSuccsessful==1 , "Pass" , "Fail")   )


  resultsDf <<- resultsDf
}

# jmeterprepDf(file=resultsfile,filterPattern = "^SC0|^_|^X_|^00_|^Bean|^Debug|^format|SignOn|^set|^[0-9]+",rtcolumn="TimeToLastByte",binsize=10)
# perf_prepDf(file=resultsfile,filterPattern = "^SC0|^_|^X_|^00_|^Bean|^Debug|^format|SignOn|^set|^[0-9]+",rtcolumn="TimeToLastByte")

txnSummary <- function(results=resultsDf,measures=c()){
  txnSum <- resultsDf %>% group_by(.,sampleLabel) %>% summarise()

  topdf <- resultsDf

  for (m in measures) {
    group_var <- "sampleLabel"  # group by this variable
    if(m=="avg"){
      summ <- paste0('round(mean(',"responseTime", '),digits=2)')
      summ_name <- paste0('', m)
      print(summ_name)
      print(paste('grouping by', group_var, 'and summarising', summ))
    }
    else{
      summ <- paste0('round(quantile(',"responseTime",",0.",m, '),digits=2)')
      summ_name <- paste0('pct_', m)
      print(summ_name)
      print(paste('grouping by', group_var, 'and summarising', summ))

    }

    df_summ <- topdf %>%
      group_by_(.dots = group_var) %>%
      summarise_(.dots = setNames(summ, summ_name))
    txnSum <- merge(txnSum,df_summ,by=c("sampleLabel"))
    print(txnSum)
    perfTestTxnSummaryDf <<- txnSum
  }
}




#
# responseTimesPlot <- function(results= results,)




