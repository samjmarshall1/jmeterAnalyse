# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

hello <- function() {
  print("Hello, world!")
}


perf_prepDf <- function(resultsDf) {


  resultsDf<-mutate(resultsDf , epoch=startTime)
  resultsDf<-mutate(resultsDf , startTime=as.POSIXct(startTime , tz=Sys.timezone() , origin="1970-01-01" ))
  resultsDf <- mutate(resultsDf, responseTime=TimeToLastByte/1000)
  resultsDf <- resultsDf %>% dplyr::filter(. , !grepl("^SC0|^_|^X_|^00_|^Bean|^Debug|^format|SignOn|^set|^[0-9]+" ,sampleLabel))


  #Change isSucessesful from 1/0 to pass/fail

  resultsDf<-mutate(resultsDf , isSuccsessful = if_else(isSuccsessful==1 , "Pass" , "Fail")   )
  # resultsDf <- resultsDf %>%filter(., isSuccsessful=="Pass")
  startTime<-min(resultsDf$startTime)
  startTimeVM <- as.POSIXct(min(resultsDf$startTime) , tz='GMT' , format="%Y-%m-%d %H:%M:%S")

  if(params$scenario=="Baseline_Test"|params$scenario=="HeadRoom_Test"){
    rampEnd<-startTime+1800
  } else if (params$scenario=="Baseline_Test_45MinuteRamp"){
    rampEnd<-startTime+2700
  } else if (params$scenario=="Smoke_Test" |  params$scenario=="NG_Smoke_Test"){
    rampEnd<-startTime+900
  } else {
    rampEnd<-startTime
  }

  endTime<-max(resultsDf$startTime, na.rm = TRUE)
  # Filter here removes ramp up
  resultsDfTable <- resultsDf %>% dplyr::filter(. , startTime>=rampEnd)
  currentId <- unique(resultsDf$RunId)

}
