# resultsfile <- "D:/EosPerformanceTestComponents/CombinedNovemberRelease/jmeterScripts/Results/Cp2_20191008_3_ADCWEN0020.csv"
#
# perf_prepDf <- function(file = file,filterPattern=filterPattern) {
#   resultsDf<-read_csv(file, col_names =TRUE , quote="\"")
#   print("################################")
#   resultsDf<-mutate(resultsDf , epoch=startTime)
#   resultsDf<-mutate(resultsDf , startTime=as.POSIXct(startTime , tz=Sys.timezone() , origin="1970-01-01" ))
#   resultsDf <- mutate(resultsDf, responseTime=TimeToLastByte/1000)
#   resultsDf <- resultsDf %>% dplyr::filter(. , !grepl(filterPattern ,sampleLabel))
#
#
#   #Change isSucessesful from 1/0 to pass/fail
#
#   resultsDf<-mutate(resultsDf , isSuccsessful = if_else(isSuccsessful==1 , "Pass" , "Fail")   )
#
#   print(unique(resultsDf$isSuccsessful))
#   typeof(resultsDf)
#   # data_compress <<- data_compress
#   resultsDf <<- resultsDf
# }
#
# perf_prepDf(file=resultsfile,filterPattern = "^SC0|^_|^X_|^00_|^Bean|^Debug|^format|SignOn|^set|^[0-9]+")
#
#
#
#
# txnSummary <- function(results=resultsDf,measures=c()){
#   txnSum <- resultsDf %>% group_by(.,sampleLabel) %>% summarise()
#
#   topdf <- resultsDf
#
#   for (m in measures) {
#     group_var <- "sampleLabel"  # group by this variable
#     if(m=="avg"){
#       summ <- paste0('mean(',"responseTime", ')')
#       summ_name <- paste0('', m)
#       print(summ_name)
#       print(paste('grouping by', group_var, 'and summarising', summ))
#     }
#     else{
#       summ <- paste0('quantile(',"responseTime",",0.",m, ')')
#       summ_name <- paste0('pct_', m)
#       print(summ_name)
#       print(paste('grouping by', group_var, 'and summarising', summ))
#
#     }
#
#     df_summ <- topdf %>%
#       group_by_(.dots = group_var) %>%
#       summarise_(.dots = setNames(summ, summ_name))
#     txnSum <- merge(txnSum,df_summ,by=c("sampleLabel"))
#     print(txnSum)
#     txnSum <<- txnSum
#   }
# }
#
#
# # topworst(results = resultsDf,measures = c('avg',95,98))
#
#
#
#





#
# measures <- list('avg',95,98,99)
# topdf <- resultsDf
#
# for (m in measures) {
#   group_var <- "sampleLabel"  # group by this variable
#   if(m=="avg"){
#     summ <- paste0('mean(',"responseTime", ')')
#     summ_name <- paste0('', m[1])
#     print(summ_name)
#     print(paste('grouping by', group_var, 'and summarising', summ))
#   }
#   else{
#     summ <- paste0('quantile(',"responseTime",",0.",m[1], ')')
#     summ_name <- paste0('pct_', m[1])
#     print(summ_name)
#     print(paste('grouping by', group_var, 'and summarising', summ))
#
#   }
#
#
#   topworst <- topdf %>%
#   group_by_(.dots = group_var) %>%
#   summarise_(.dots = setNames(summ, summ_name))
#
#
#
#   print(topworst)
# }
#
#

