library(testthat)
library(perfReports)

test_check("perfReports")

