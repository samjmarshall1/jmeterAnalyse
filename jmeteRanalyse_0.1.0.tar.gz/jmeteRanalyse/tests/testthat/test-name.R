test_that("resultsdf prep works and txn summary", {
  resultsfile <- "D:/EosPerformanceTestComponents/CombinedNovemberRelease/jmeterScripts/Results/Cp2_20191008_3_ADCWEN0020.csv"

  jmeterprepDf(file=resultsfile,filterPattern = "^SC0|^_|^X_|^00_|^Bean|^Debug|^format|SignOn|^set|^[0-9]+",rtcolumn="TimeToLastByte",binsize=10)
  # txnSummary(results = resultsDf,measures = c('avg',95,98))

})

# test_that("txn summary works",{
#
#   txnSummary(results = resultsDf,measures = c('avg',95,98))
#
# })
